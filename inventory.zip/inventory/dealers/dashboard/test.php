<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Themify Icon Font</title>
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" href="css/themify-icons/demo-files/demo.css">
	<link rel="stylesheet" href="css/themify-icons/themify-icons.css">
	<!--[if lt IE 8]><!-->
	<link rel="stylesheet" href="ie7/ie7.css">
	<!--<![endif]-->
</head>

<body>
 <i class="ti-home"> </i>
 <span class="ti-arrow-up"></span>

</body>
</html>