<?php

$con = mysqli_connect("localhost","vinnyhut_invt","W~#^K[Ua40X=","vinnyhut_inventory");
?>