<?php include_once("header.php"); ?>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                       
                       <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1">vindecode</h2>
                                  
                                </div>
                            </div>
                        </div>
                         
                     
                        
                        
                        <?php include_once("footer1.php"); ?>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
   <?php include_once("footer2.php"); ?>

</body>

</html>
<!-- end document-->
