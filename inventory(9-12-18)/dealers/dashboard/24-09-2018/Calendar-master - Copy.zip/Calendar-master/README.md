# Calendar
A simple implementation of [fullCalendar] (https://github.com/fullcalendar/fullcalendar)

# Features
- Adding events to the calendar
- Viewing of created events on the calendar
- Event description shows on mouseover

# To-Do
- Updating of events
- Deleting events
- Day selection
- Drag and drop

# Demo
View demo here (https://1410inc.xyz/calendar/)
